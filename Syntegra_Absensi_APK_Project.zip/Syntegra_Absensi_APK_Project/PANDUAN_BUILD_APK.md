# Panduan Mengemas Paket Aplikasi Menjadi File `.APK` Android
**Syntegra Services - Sistem Absensi Digital (Foto & GPS)**

Lingkungan AI tidak dapat mengeksekusi kompilasi Android SDK (`gradle`) secara langsung menjadi file biner `.apk`, sehingga seluruh aset aplikasi yang **bebas dari error loading cloud** telah dikemas dalam paket proyek siap pakai ini.

---

## Opsi 1: Langsung Pasang di HP Android Tanpa Kompilasi (Paling Cepat - 1 Menit)
Aplikasi ini sudah dilengkapi konfigurasi **Progressive Web App (PWA)** sehingga bisa langsung diinstal ke layar utama HP Android layaknya aplikasi `.apk` asli dengan akses penuh ke **Kamera Depan** dan **GPS**:
1. Ekstrak folder `www/` dari file ZIP ini.
2. Unggah folder `www/` secara gratis ke **Netlify Drop** (`app.netlify.com/drop`) atau **Vercel** (cukup *drag & drop* foldernya).
3. Buka link HTTPS yang muncul menggunakan **Google Chrome** di HP Android.
4. Tekan ikon **Titik Tiga (⋮)** di pojok kanan atas Chrome → pilih **"Tambahkan ke Layar Utama" (Add to Home Screen)** → **"Instal"**.
5. Ikon perisai emas **Syntegra Absen** akan terpasang di menu HP Android Anda dan berjalan layar penuh (*fullscreen*) tanpa bilah browser.

---

## Opsi 2: Build File `.APK` Mentah (Untuk Dibagikan ke Karyawan)
Jika Anda membutuhkan file `Syntegra-Absensi.apk` untuk dibagikan lewat WhatsApp atau diunggah ke Google Play Store:

### Cara A: Menggunakan PWABuilder (Tanpa Coding / Tanpa Install Android Studio)
1. Unggah folder `www/` ke hosting gratis (Netlify Drop / Vercel / GitHub Pages).
2. Buka **[pwabuilder.com](https://www.pwabuilder.com)**, masukkan URL aplikasi Anda, lalu klik **Start**.
3. Klik **Package for Stores** → pilih **Android** → klik **Generate Package**.
4. Unduh file ZIP hasilnya — di dalamnya sudah tersedia file **`.apk`** siap instal di semua HP Android.

### Cara B: Menggunakan Capacitor / Android Studio (Jika Punya Laptop dengan Node.js)
1. Buka terminal di dalam folder ekstrak proyek ini, lalu jalankan perintah:
   ```bash
   npm init -y
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap add android
   npx cap copy android
   ```
2. Salin file `AndroidManifest.xml` yang ada di paket ini ke `android/app/src/main/AndroidManifest.xml` (agar izin **Kamera** dan **GPS** aktif di Android).
3. Jalankan perintah berikut untuk menghasilkan file `.apk`:
   ```bash
   cd android && ./gradlew assembleDebug
   ```
4. File `.apk` siap pakai akan muncul di:
   `android/app/build/outputs/apk/debug/app-debug.apk`
